title Run kasir
python kasir.py
cls