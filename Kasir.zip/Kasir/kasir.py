import os
import sqlite3
import textwrap
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk


DATABASE_PATH = Path(__file__).resolve().with_name("kasir.db")


def rupiah(amount):
    return "Rp {:,}".format(amount).replace(",", ".")


class KasirApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Kasir")
        self.root.geometry("1020x680")
        self.root.minsize(850, 560)

        self.connection = sqlite3.connect(DATABASE_PATH)
        self.connection.execute("PRAGMA foreign_keys = ON")
        self._create_tables()

        self.cart = {}
        self.selected_product_id = None
        self.latest_sale_id = self._get_latest_sale_id()

        self._build_ui()
        self.refresh_products()
        self.refresh_cart()
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _create_tables(self):
        with self.connection:
            self.connection.execute(
                """
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    price INTEGER NOT NULL CHECK (price > 0)
                )
                """
            )
            self.connection.execute(
                """
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    total INTEGER NOT NULL,
                    paid INTEGER NOT NULL,
                    change_due INTEGER NOT NULL
                )
                """
            )
            self.connection.execute(
                """
                CREATE TABLE IF NOT EXISTS sale_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
                    product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
                    product_name TEXT NOT NULL,
                    price INTEGER NOT NULL,
                    quantity INTEGER NOT NULL,
                    subtotal INTEGER NOT NULL
                )
                """
            )

    def _build_ui(self):
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.columnconfigure(1, weight=2)
        main.rowconfigure(0, weight=1)

        catalog = ttk.LabelFrame(main, text="Data Barang", padding=10)
        catalog.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        catalog.columnconfigure(0, weight=1)
        catalog.rowconfigure(0, weight=1)

        product_columns = ("name", "price")
        self.product_tree = ttk.Treeview(
            catalog, columns=product_columns, show="headings", height=12
        )
        self.product_tree.heading("name", text="Nama barang")
        self.product_tree.heading("price", text="Harga")
        self.product_tree.column("name", width=170)
        self.product_tree.column("price", width=110, anchor="e")
        product_scroll = ttk.Scrollbar(
            catalog, orient="vertical", command=self.product_tree.yview
        )
        self.product_tree.configure(yscrollcommand=product_scroll.set)
        self.product_tree.grid(row=0, column=0, sticky="nsew")
        product_scroll.grid(row=0, column=1, sticky="ns")
        self.product_tree.bind("<<TreeviewSelect>>", self.on_product_selected)

        form = ttk.LabelFrame(catalog, text="Tambah / ubah barang", padding=8)
        form.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text="Nama barang").grid(row=0, column=0, sticky="w", pady=4)
        self.name_entry = ttk.Entry(form)
        self.name_entry.grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Label(form, text="Harga (Rp)").grid(row=1, column=0, sticky="w", pady=4)
        self.price_entry = ttk.Entry(form)
        self.price_entry.grid(row=1, column=1, sticky="ew", pady=4)

        product_buttons = ttk.Frame(form)
        product_buttons.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        ttk.Button(product_buttons, text="Simpan barang", command=self.save_product).pack(
            side="left", expand=True, fill="x"
        )
        ttk.Button(product_buttons, text="Hapus barang", command=self.delete_product).pack(
            side="left", expand=True, fill="x", padx=(6, 0)
        )
        ttk.Button(
            product_buttons, text="Bersihkan", command=self.clear_product_form
        ).pack(side="left", expand=True, fill="x", padx=(6, 0))

        cashier = ttk.LabelFrame(main, text="Kasir", padding=10)
        cashier.grid(row=0, column=1, sticky="nsew")
        cashier.columnconfigure(0, weight=1)
        cashier.rowconfigure(0, weight=1)

        cart_columns = ("name", "price", "quantity", "subtotal")
        self.cart_tree = ttk.Treeview(
            cashier, columns=cart_columns, show="headings", height=15
        )
        for column, heading in (
            ("name", "Nama barang"),
            ("price", "Harga"),
            ("quantity", "Jumlah"),
            ("subtotal", "Subtotal"),
        ):
            self.cart_tree.heading(column, text=heading)
        self.cart_tree.column("name", width=190)
        self.cart_tree.column("price", width=100, anchor="e")
        self.cart_tree.column("quantity", width=65, anchor="center")
        self.cart_tree.column("subtotal", width=110, anchor="e")
        cart_scroll = ttk.Scrollbar(
            cashier, orient="vertical", command=self.cart_tree.yview
        )
        self.cart_tree.configure(yscrollcommand=cart_scroll.set)
        self.cart_tree.grid(row=0, column=0, sticky="nsew")
        cart_scroll.grid(row=0, column=1, sticky="ns")

        cart_actions = ttk.Frame(cashier)
        cart_actions.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Label(cart_actions, text="Jumlah").pack(side="left")
        self.quantity_spinbox = ttk.Spinbox(
            cart_actions, from_=1, to=9999, width=6, justify="center"
        )
        self.quantity_spinbox.set("1")
        self.quantity_spinbox.pack(side="left", padx=(5, 12))
        ttk.Button(
            cart_actions, text="Tambah barang terpilih", command=self.add_to_cart
        ).pack(side="left", expand=True, fill="x")
        ttk.Button(
            cart_actions, text="Hapus dari keranjang", command=self.remove_from_cart
        ).pack(side="left", expand=True, fill="x", padx=(6, 0))
        ttk.Button(
            cart_actions, text="Kosongkan", command=self.clear_cart
        ).pack(side="left", padx=(6, 0))

        payment = ttk.LabelFrame(cashier, text="Pembayaran", padding=10)
        payment.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        payment.columnconfigure(1, weight=1)
        self.total_var = tk.StringVar(value=rupiah(0))
        self.change_var = tk.StringVar(value=rupiah(0))
        ttk.Label(payment, text="Total belanja", font=("", 12, "bold")).grid(
            row=0, column=0, sticky="w", pady=3
        )
        ttk.Label(payment, textvariable=self.total_var, font=("", 12, "bold")).grid(
            row=0, column=1, sticky="e", pady=3
        )
        ttk.Label(payment, text="Uang diterima (Rp)").grid(
            row=1, column=0, sticky="w", pady=3
        )
        self.paid_entry = ttk.Entry(payment)
        self.paid_entry.grid(row=1, column=1, sticky="ew", pady=3)
        self.paid_entry.bind("<KeyRelease>", self.update_change)
        ttk.Label(payment, text="Kembalian").grid(row=2, column=0, sticky="w", pady=3)
        ttk.Label(payment, textvariable=self.change_var).grid(
            row=2, column=1, sticky="e", pady=3
        )

        payment_buttons = ttk.Frame(payment)
        payment_buttons.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Button(
            payment_buttons, text="Simpan transaksi", command=self.complete_sale
        ).pack(side="left", expand=True, fill="x")
        ttk.Button(
            payment_buttons, text="Cetak struk terakhir", command=self.print_latest_receipt
        ).pack(side="left", expand=True, fill="x", padx=(6, 0))

    def refresh_products(self):
        children = self.product_tree.get_children()
        if children:
            self.product_tree.delete(*children)
        try:
            rows = self.connection.execute(
                "SELECT id, name, price FROM products ORDER BY name COLLATE NOCASE"
            ).fetchall()
        except sqlite3.Error as error:
            messagebox.showerror("Kesalahan database", str(error), parent=self.root)
            return
        for product_id, name, price in rows:
            self.product_tree.insert(
                "", "end", iid=str(product_id), values=(name, rupiah(price))
            )

    def on_product_selected(self, _event=None):
        selection = self.product_tree.selection()
        if not selection:
            return
        self.selected_product_id = int(selection[0])
        try:
            row = self.connection.execute(
                "SELECT name, price FROM products WHERE id = ?",
                (self.selected_product_id,),
            ).fetchone()
        except sqlite3.Error as error:
            messagebox.showerror("Kesalahan database", str(error), parent=self.root)
            return
        if row is not None:
            self.name_entry.delete(0, "end")
            self.name_entry.insert(0, row[0])
            self.price_entry.delete(0, "end")
            self.price_entry.insert(0, str(row[1]))

    def _read_product_form(self):
        name = self.name_entry.get().strip()
        price_text = self.price_entry.get().strip()
        if not name:
            messagebox.showwarning("Data belum lengkap", "Nama barang wajib diisi.")
            return None
        if not price_text.isdecimal() or int(price_text) <= 0:
            messagebox.showwarning(
                "Harga tidak valid", "Harga harus berupa angka bulat lebih dari 0."
            )
            return None
        return name, int(price_text)

    def save_product(self):
        product = self._read_product_form()
        if product is None:
            return
        name, price = product
        try:
            with self.connection:
                if self.selected_product_id is None:
                    self.connection.execute(
                        "INSERT INTO products (name, price) VALUES (?, ?)",
                        (name, price),
                    )
                else:
                    self.connection.execute(
                        "UPDATE products SET name = ?, price = ? WHERE id = ?",
                        (name, price, self.selected_product_id),
                    )
        except sqlite3.Error as error:
            messagebox.showerror("Gagal menyimpan barang", str(error), parent=self.root)
            return
        self.clear_product_form()
        self.refresh_products()

    def delete_product(self):
        if self.selected_product_id is None:
            messagebox.showwarning(
                "Pilih barang", "Pilih barang dari daftar yang ingin dihapus."
            )
            return
        if not messagebox.askyesno(
            "Hapus barang", "Yakin ingin menghapus barang yang dipilih?"
        ):
            return
        try:
            with self.connection:
                self.connection.execute(
                    "DELETE FROM products WHERE id = ?", (self.selected_product_id,)
                )
        except sqlite3.Error as error:
            messagebox.showerror("Gagal menghapus barang", str(error), parent=self.root)
            return
        self.clear_product_form()
        self.refresh_products()

    def clear_product_form(self):
        self.selected_product_id = None
        selection = self.product_tree.selection()
        if selection:
            self.product_tree.selection_remove(*selection)
        self.name_entry.delete(0, "end")
        self.price_entry.delete(0, "end")

    def add_to_cart(self):
        selection = self.product_tree.selection()
        if not selection:
            messagebox.showwarning(
                "Pilih barang", "Pilih barang dari daftar data barang terlebih dahulu."
            )
            return
        quantity_text = self.quantity_spinbox.get().strip()
        if not quantity_text.isdecimal() or int(quantity_text) <= 0:
            messagebox.showwarning("Jumlah tidak valid", "Jumlah harus lebih dari 0.")
            return
        product_id = int(selection[0])
        try:
            product = self.connection.execute(
                "SELECT name, price FROM products WHERE id = ?", (product_id,)
            ).fetchone()
        except sqlite3.Error as error:
            messagebox.showerror("Kesalahan database", str(error), parent=self.root)
            return
        if product is None:
            messagebox.showerror(
                "Barang tidak ditemukan", "Muat ulang daftar dan pilih barang kembali."
            )
            self.refresh_products()
            return
        name, price = product
        if product_id in self.cart:
            self.cart[product_id]["quantity"] += int(quantity_text)
        else:
            self.cart[product_id] = {
                "name": name,
                "price": price,
                "quantity": int(quantity_text),
            }
        self.refresh_cart()

    def remove_from_cart(self):
        selection = self.cart_tree.selection()
        if not selection:
            messagebox.showwarning(
                "Pilih barang", "Pilih barang dari keranjang yang ingin dihapus."
            )
            return
        self.cart.pop(int(selection[0]), None)
        self.refresh_cart()

    def clear_cart(self):
        self.cart.clear()
        self.refresh_cart()

    def refresh_cart(self):
        children = self.cart_tree.get_children()
        if children:
            self.cart_tree.delete(*children)
        total = 0
        for product_id, item in self.cart.items():
            subtotal = item["price"] * item["quantity"]
            total += subtotal
            self.cart_tree.insert(
                "",
                "end",
                iid=str(product_id),
                values=(
                    item["name"],
                    rupiah(item["price"]),
                    item["quantity"],
                    rupiah(subtotal),
                ),
            )
        self.total_var.set(rupiah(total))
        self.update_change()

    def update_change(self, _event=None):
        paid_text = self.paid_entry.get().strip()
        paid = int(paid_text) if paid_text.isdecimal() else 0
        total = sum(
            item["price"] * item["quantity"] for item in self.cart.values()
        )
        self.change_var.set(rupiah(max(0, paid - total)))

    def complete_sale(self):
        if not self.cart:
            messagebox.showwarning("Keranjang kosong", "Tambahkan barang sebelum menyimpan.")
            return
        paid_text = self.paid_entry.get().strip()
        if not paid_text.isdecimal():
            messagebox.showwarning(
                "Pembayaran tidak valid", "Masukkan uang diterima dalam angka bulat."
            )
            return
        paid = int(paid_text)
        total = sum(
            item["price"] * item["quantity"] for item in self.cart.values()
        )
        if paid < total:
            messagebox.showwarning(
                "Pembayaran kurang",
                "Uang diterima belum cukup untuk membayar total belanja.",
            )
            return

        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        change_due = paid - total
        try:
            with self.connection:
                cursor = self.connection.execute(
                    """
                    INSERT INTO sales (created_at, total, paid, change_due)
                    VALUES (?, ?, ?, ?)
                    """,
                    (created_at, total, paid, change_due),
                )
                sale_id = cursor.lastrowid
                self.connection.executemany(
                    """
                    INSERT INTO sale_items
                        (sale_id, product_id, product_name, price, quantity, subtotal)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            sale_id,
                            product_id,
                            item["name"],
                            item["price"],
                            item["quantity"],
                            item["price"] * item["quantity"],
                        )
                        for product_id, item in self.cart.items()
                    ],
                )
        except sqlite3.Error as error:
            messagebox.showerror("Gagal menyimpan transaksi", str(error), parent=self.root)
            return

        self.latest_sale_id = sale_id
        self.clear_cart()
        self.paid_entry.delete(0, "end")
        messagebox.showinfo(
            "Transaksi tersimpan",
            "Transaksi #{} berhasil disimpan.\nKembalian: {}".format(
                sale_id, rupiah(change_due)
            ),
            parent=self.root,
        )

    def _get_latest_sale_id(self):
        try:
            row = self.connection.execute(
                "SELECT id FROM sales ORDER BY id DESC LIMIT 1"
            ).fetchone()
        except sqlite3.Error as error:
            messagebox.showerror("Kesalahan database", str(error), parent=self.root)
            return None
        return row[0] if row else None

    def _make_receipt(self, sale_id):
        try:
            sale = self.connection.execute(
                "SELECT created_at, total, paid, change_due FROM sales WHERE id = ?",
                (sale_id,),
            ).fetchone()
            items = self.connection.execute(
                """
                SELECT product_name, price, quantity, subtotal
                FROM sale_items WHERE sale_id = ? ORDER BY id
                """,
                (sale_id,),
            ).fetchall()
        except sqlite3.Error as error:
            messagebox.showerror("Gagal membaca transaksi", str(error), parent=self.root)
            return None
        if sale is None:
            messagebox.showerror(
                "Transaksi tidak ditemukan", "Data transaksi tidak tersedia."
            )
            return None

        created_at, total, paid, change_due = sale
        width = 32
        separator = "=" * width
        thin_separator = "-" * width
        try:
            receipt_date = datetime.fromisoformat(created_at).strftime(
                "%d-%m-%Y %H:%M"
            )
        except ValueError:
            receipt_date = created_at

        lines = [
            separator,
            "STRUK PEMBELIAN".center(width),
            "RAIA".center(width),
            separator,
            "No. transaksi : #{}".format(str(sale_id).zfill(6)),
            "Waktu         : {}".format(receipt_date),
            thin_separator,
        ]
        for name, price, quantity, subtotal in items:
            lines.extend(
                textwrap.wrap(
                    name,
                    width=width,
                    break_long_words=True,
                    break_on_hyphens=False,
                )
                or [""]
            )
            detail = "  {} x {}".format(quantity, rupiah(price))
            amount = rupiah(subtotal)
            if len(detail) + len(amount) + 1 <= width:
                lines.append(
                    "{}{}".format(detail.ljust(width - len(amount)), amount)
                )
            else:
                lines.extend((detail, amount.rjust(width)))
            lines.append("")

        def summary_row(label, amount):
            label_width = 11
            return "{}{}".format(
                label.ljust(label_width), amount.rjust(width - label_width)
            )

        lines.extend(
            [
                thin_separator,
                summary_row("TOTAL", rupiah(total)),
                summary_row("TUNAI", rupiah(paid)),
                summary_row("KEMBALIAN", rupiah(change_due)),
                separator,
                "TERIMA KASIH".center(width),
                "Selamat berbelanja kembali".center(width),
                "",
            ]
        )
        return "\n".join(lines)

    def print_latest_receipt(self):
        if self.latest_sale_id is None:
            messagebox.showwarning(
                "Belum ada transaksi", "Simpan transaksi terlebih dahulu."
            )
            return
        receipt = self._make_receipt(self.latest_sale_id)
        if receipt is None:
            return
        receipt_dir = Path(__file__).resolve().with_name("struk")
        receipt_path = receipt_dir / "struk_{}.txt".format(self.latest_sale_id)
        try:
            receipt_dir.mkdir(exist_ok=True)
            receipt_path.write_text(receipt, encoding="utf-8")
        except OSError as error:
            messagebox.showerror("Gagal membuat struk", str(error), parent=self.root)
            return

        if os.name != "nt":
            messagebox.showinfo(
                "Struk disimpan",
                "Struk tersimpan di:\n{}\n\nCetak struk tersedia pada Windows.".format(
                    receipt_path
                ),
                parent=self.root,
            )
            return
        try:
            os.startfile(str(receipt_path), "print")
        except OSError as error:
            messagebox.showerror(
                "Gagal mencetak",
                "Struk tersimpan di:\n{}\n\nTidak dapat mengirim struk ke printer:\n{}".format(
                    receipt_path, error
                ),
                parent=self.root,
            )
            return
        messagebox.showinfo(
            "Struk dicetak",
            "Permintaan cetak dikirim ke aplikasi printer default.\nFile struk: {}".format(
                receipt_path
            ),
            parent=self.root,
        )

    def close(self):
        self.connection.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    KasirApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()